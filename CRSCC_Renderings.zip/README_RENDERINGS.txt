Add your CRSCC renderings (PNG/JPG) to this ZIP before publishing.
Suggested filenames: exterior_night.png, interior_track.png, pool.png, courts.png